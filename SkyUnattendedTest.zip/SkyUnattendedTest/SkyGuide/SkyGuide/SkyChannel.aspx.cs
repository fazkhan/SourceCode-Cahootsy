﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

namespace SkyGuide
{
    public partial class SkyChannel : System.Web.UI.Page
    {
        string xmlURL;
        ActorsNames objAN = new ActorsNames();
        string[] arrChannel;

        protected void Page_Load(object sender, EventArgs e)
        {
            arrChannel = objAN.getActors();
            programGuide();
        }

        protected void onclick_btn(Object sender, EventArgs e)
        {
            if (fUpload.HasFile)
            {
                try
                {
                    fUpload.SaveAs(Server.MapPath("~/App_Data/") + fUpload.FileName);
                    lblFileMsg.Text = "File: " + fUpload.FileName + " has been uploaded successfully.";
                    programGuide();
                }
                catch (Exception)
                {
                    lblFileMsg.Text = "There is an ERROR during uplaoding a file.";
                }
            }
            else
                lblFileMsg.Text = "You have not chosen any file. Please select file and click on upload button.";
        }

        /**
         * This function will take the file name from web.config
         * load the xml file from app_data folder
         * with no parameter 
         **/
        protected void programGuide()
        {
            try
            {
                xmlURL = Server.MapPath("~/App_Data/" + System.Configuration.ConfigurationManager.AppSettings["XmlDataFileName"]);
                XmlDocument doc = new XmlDocument();
                doc.Load(xmlURL);

                int maxTime = getTime(doc);
                addHoursCol(maxTime);
                generateTableWithData(doc, maxTime);
            }
            catch (Exception e)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('There is an Error in uploaded File. Please check the file format.')", true);

            }

        }

        /**
         * This function takes XMLDocument as aparameter
         * Find out the maximum time
         * if time is greater than 3.00PM, it will return additional hours to apply the scroll fucntionality
         * **/
        protected int getTime(XmlDocument doc)
        {
            int maxTime = 0;
            XmlNodeList node1 = doc.SelectNodes(".//end_time");
            List<DateTime> lstInt = new List<DateTime>();
            foreach (XmlNode n1 in node1)
            {

                if (n1.InnerText.ToLower().Contains("pm"))
                {
                    lstInt.Add(Convert.ToDateTime(n1.InnerText));
                }
            }
            int hour = lstInt.Max().TimeOfDay.Subtract(TimeSpan.FromHours(15)).Hours;
            if (hour < 0)
                hour = 0;
            int min = lstInt.Max().TimeOfDay.Subtract(TimeSpan.FromHours(15)).Minutes;
            maxTime = (hour > 0 || min > 0) ? hour + 1 : hour;
            return maxTime;
        }


        /**
         * This Function creates a dynamic columns if 
         * max time is greater than 3.00PM
         * It takes maxTime, return by getTime(XmlDocument doc) as a parameter
         * **/
        protected void addHoursCol(int maxTime)
        {

            if (maxTime > 0)
            {
                ltr.Text = "<table id='tblMovie' style='width:760px;'><tr style='background-color: #d3d3d3;'><td> Channel </td><td> 9 AM </td><td> 10 AM </td><td> 11 AM </td><td> 12 PM </td><td> 1 PM </td><td> 2 PM </td><td> 3 PM </td>";

                for (int a = 1; a <= maxTime; a++)
                {

                    ltr.Text += "<td > " + (a + 3) + " PM </td>";
                }
            }
            else
                ltr.Text = "<table id='tblMovie' style='width:628px;'><tr style='background-color: #d3d3d3;'><td> Channel </td><td> 9 AM </td><td> 10 AM </td><td> 11 AM </td><td> 12 PM </td><td> 1 PM </td><td> 2 PM </td><td> 3 PM </td>";

            ltr.Text += "</tr>";
        }

        /**
         * This function filled the data into table respective to every actor
         * It also takes XmlDocument and maxTime as its parameters
         * **/
        protected void generateTableWithData(XmlDocument doc, int maxTime)
        {

            DateTime startDate;
            DateTime endDate;
            for (int i = 0; i < arrChannel.Length; i++)
            {
                double totalNumofCol = 7 + maxTime;
                string channelName = arrChannel[i].Split(' ')[0].ToString();
                channelName = channelName.ToLower() + "_channel";
                XmlNodeList node = doc.SelectNodes("/movie_data/movie/" + channelName);

                // If there is no data against actor, it will write No programmes avaialable
                ltr.Text += "<tr><td style='background-color: #d3d3d3;'> " + arrChannel[i] + "</td>";
                if (node.Count <= 0)
                {
                    ltr.Text += "<td colspan=" + totalNumofCol + " style='padding-left: 60px;'> No programmes available </td>";
                }

                //Fill the data according to respective actors
                foreach (XmlNode n in node)
                {

                    startDate = Convert.ToDateTime(n.SelectSingleNode(".//start_time").InnerText);
                    endDate = Convert.ToDateTime(n.SelectSingleNode(".//end_time").InnerText);
                    TimeSpan ts = endDate.TimeOfDay.Subtract(startDate.TimeOfDay);
                    double hours = Math.Ceiling(ts.TotalHours);


                    ltr.Text += " <td colspan=" + hours + "> <a href='#' onclick='showPopup(this); return false;'  id='" + n.FirstChild.InnerText + "'> " + n.FirstChild.InnerText + "</a> </td>";
                    totalNumofCol = totalNumofCol - hours;

                }

                if (totalNumofCol > 0 && node.Count > 0)
                {
                    ltr.Text += "<td colspan=" + totalNumofCol + "/>";
                }

                ltr.Text += "</tr>";
            }

            ltr.Text += "<table>";
        }
    }
}