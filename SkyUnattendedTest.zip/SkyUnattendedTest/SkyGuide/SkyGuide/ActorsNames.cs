﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SkyGuide
{
    public class ActorsNames
    {
        string[] arrChannel;// = new string[] { "Sean Connery", "George Lazenby", "Roger Moore", "Timothy Dalton", "Pierce Brosnan", "Daniel Crag" };

        public string[] getActors()
        {
            arrChannel = new string[] { "Sean Connery", "George Lazenby", "Roger Moore", "Timothy Dalton", "Pierce Brosnan", "Daniel Crag" };
            return arrChannel;

        }
    }
}